let baseUrl = "https://www.tiktok.com/@";

chrome.runtime.onMessage.addListener(gotUsernames);
// runtime message handler
function gotUsernames(message, sender, sendResponse) {
  // Following
  if (message.action == 3) {
    try {
      // follow action
      document.querySelector('button[data-e2e="follow-button"]').style["background-color"] = "blue";
      // followed confirmation message to background script
      let msg = {
        action: 2,
        uname: document.baseURI.split("@")[1]
      }
      chrome.runtime.sendMessage(msg);
    } catch (err) {
      console.log("Seems Already Followed that user...");
    }
    next(message.uname)
  }
  // Start popup
  else if (message.action == 4) {
    console.log("Starting");
    // createing start popup
    let start_message = document.createElement('div');
    start_message.classList.add("alert");
    start_message.classList.add("alert-success");
    start_message.classList.add("text-center");
    start_message.classList.add("h5");
    start_message.classList.add("fixed-top");
    start_message.setAttribute("role", "alert");
    start_message.innerText = "Starting the Extension...";
    document.querySelector('div[class*="DivHeaderCenterContainer"]').appendChild(start_message);
  }
  // Stop popup
  else if (message.action == 5) {
    console.log("Stopped");
    // creating stop popup
    let stop_message = document.createElement('div');
    stop_message.classList.add("alert");
    stop_message.classList.add("alert-success");
    stop_message.classList.add("text-center");
    stop_message.classList.add("h5");
    stop_message.classList.add("fixed-top");
    stop_message.setAttribute("role", "alert");
    stop_message.innerText = "Extension Stopped...";
    document.querySelector('div[class*="DivHeaderCenterContainer"]').appendChild(stop_message);
    setTimeout(() => {
      stop_message.remove()
    }, 5000);
  }
}

// visit next user
function next(uname) {
  window.location.replace(`${baseUrl}${uname}`);
}