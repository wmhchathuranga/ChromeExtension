let options = {
  active: true,
  lastFocusedWindow: true
}

chrome.tabs.query(options, moveToTiktok);
// need to be in tiktok page to lauch the extension
function moveToTiktok(tabs) {
  current_url = tabs[0].url;
  console.log(current_url);
  if (!(current_url.includes("https://www.tiktok.com/"))) {
    chrome.tabs.create({
      url: "https://www.tiktok.com/"
    })
  }
}



let imgUrl = chrome.extension.getURL("bg.png");
console.log(imgUrl);
document.getElementById('logo-img').src = imgUrl;
let storage = window.localStorage;

// Run button
let run_button = document.getElementById('run').addEventListener('click', run);

// stop button
let stop_button = document.getElementById('stop').addEventListener('click', stop);

document.getElementById('uname').value = storage.getItem('uname');

function run() {
  let uname = document.getElementById('uname').value;
  storage.setItem('uname', uname);
  console.log(uname);

  // start message
  let msg = {
    action: 1,
    uname: storage.getItem('uname')
  }
  chrome.runtime.sendMessage(msg);
  window.close()
}

// stop message
function stop() {
  let msg = {
    action: 0
  }
  chrome.runtime.sendMessage(msg);
  window.close()

}