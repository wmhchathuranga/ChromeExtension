// TODO: API connection

let options = {
  active: true,
  currentWindow: true
}

var followedBy = "";
let interval_id;


// api request
function api() {
  // chrome.tabs.query(options, sendName);
  sendName(window.tabs);
}

function start() {
  chrome.tabs.query(options, startMessage);
}

function stop() {
  // chrome.tabs.query(options, stopMessage);
  stopMessage(window.tabs)
}

function startMessage(tabs) {
  window.tabs = tabs;
  let msg = {
    action: 4
  }
  try {
    chrome.tabs.sendMessage(tabs[0].id, msg)
  } catch (err) {
    console.log(err);
  }
}

function stopMessage(tabs) {
  let msg = {
    action: 5
  }
  try {
    chrome.tabs.sendMessage(tabs[0].id, msg)
  } catch (err) {
    console.log(err);
  }
}
// send username to content script
function sendName(tabs) {
  let index = Math.floor(Math.random() * 37);
  // username message
  // fetch(`http://127.0.0.1:8080/get?id=${index}`)

  fetch(`http://127.0.0.1/TikTok%20API/MyAPI/control/userAPI.php?id=${index}`)
    .then(response => response.json())
    .then(data => {
      try {
        console.log(data.username);
        let msg = {
          action: 3,
          uname: data.username
        };

        chrome.tabs.sendMessage(tabs[0].id, msg)
      } catch (err) {
        console.log(data.username);
      }
    });

}

chrome.runtime.onMessage.addListener(msgHandler);
// runtime message handler
function msgHandler(message, sender, sendResponse) {
  // stop extension
  if (message.action == 0) {
    stop()
    clearInterval(interval_id);
  }
  // run extension
  else if (message.action == 1) {
    start()
    window.uname = message.uname;
    console.log(uname);
    // Handle multiple runs
    clearInterval(interval_id);
    interval_id = setInterval(api, 1000 * 10)
  }
  // followed confirmation to API
  else if (message.action == 2) {
    let apiRequest = {
      followed_by: window.uname,
      follower: message.uname
    }
    apiRequest = JSON.stringify(apiRequest);
    fetch('http://127.0.0.1/TikTok%20API/MyAPI/control/followerAPI.php', {
      method: 'POST',
      body: apiRequest,
      headers: {
        'Content-Type': 'application/json'
      }
    })
    console.log(apiRequest);
  }
}